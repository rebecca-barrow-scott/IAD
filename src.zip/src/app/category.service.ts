import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { IconService } from './icon.service';
import { File } from '@ionic-native/file/ngx';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categories = [];
  constructor( private storage:Storage, private iconService:IconService, private file:File) { }
  //get the value of categories from storage, if null define a new value and update storage
  async getCategories(){
    this.categories = await this.storage.get("categories");
    //this.categories = null;
      if (this.categories == null) {
        this.categories = [
        {id: 'c0', name: "foundation", icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAABn0lEQVRoge2YvUoDQRSFv0iEaGsRfAALQYuUpouF76KP4CvYCL5AnsAHsFCS+BMULAIRK21Ei2AhipWgxd4lJmx+duauOyv3g+FCZubknN3ZGZgSupwCNaAv7QY4B+6V/ydzvie0F+AIqAOl3NyloEdkvA3sA8fAK6OhznJzl4I68CVtS34rAw3gkGGYQnBAZLaX0FeoIBUmGy5UkAtmB+n8qSNHYrPthL4OBXors4xmEmRBUeuEUYOTzpTf/WpLTPNwcn3KKh7KGiJjzGtMdXlpLq1csSChYUEYbrdJ2+o8LWm883bss/VldTo7edLYfrXOIq8HY99IaFiQ0LAgoWFBQsOChIYFCQ0LEhoWJDQsSGhYEOBT6pKCj2WpH64CPkEGUlc8NGJijcHUUVPwCfIgdcNDI2ZT6qOrgE+QltSGh0ZMrNGaOiojakR3UU/43Y8tAs+iVVPw5cSVGNj10NgTjUsVR45si4l3YN1h/hrwJho7ir6caBIZ6QPVFPOqwJ3Mbaq7cqACXDP/Lfx4u2V4juTOKtAlfYiuzDX+HT8BtYidLCl8CAAAAABJRU5ErkJggg==", note: "A collection of foundations I have used."},
        {id: 'c1', name: "blush", icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAFlElEQVRoge3ZaahVVRQH8N9zymdo+swUNC2paFDLBiErDAoaCBqggQoqgwaygShIIho+VAR9ysrm8UsYBFGUUBGRFUFpOUVFpc1WWlaa9XyvD2sfzrm3O7/z3ofwD5sLd6+99tp7r+G/92EXdmEXGqGrRF27YR6OwXzMQA8mpv5fsBlf4Z3U3seOEm0YEA7A3diE/jbbFjyE2UNudQGT8Dj65IatwRKcjzmYiu7Upqb/zk8yawvj+vAY9hzSFeAs4Sr9+Evs6pEd6DkKDycd/UnnmSXZ2BRXY2ea+A0cVILO/fCK/HRuKEFnQ1xZmOymFuS7cSfexF4tyC+Wu+rlnZnYHIdie5rk4hbkj8dnSf5v/z25EXXGLUxjtouYKhXDsCpNcF8T2fHC77OdXYOjq2ROx9d4rY6O+9PYlcotEU5Lir8T9aIezsC3SXYHbsOoQv9kPCfPVs/V0TMa3yeZUwZg93/wTFJ6a53+KVhWMPBdHFIlc5E8023FVeKk6+H2JPtUx1bXwOdJaa0UO05eDH/HNVUG7oPl8kW+jL1bmPOoJP9pp0bXQhbkE2r0jRG+/KKgJRmG41r8kcZuEsWwiDk4oc6cPWncto6troFGC6mFQ4R7ZafwrGACGbpxD/4RSWFStQKDtJBGrlXEKBHgO5L8RpxaJbNAnpZ7cVcdXfMMgms9nZTe1kDmSJFq+0XlX4Kxhf49sFSelj9OxtbDHUnuyQ5trolTk9LvRWqshW+SzHocW9V3mqgbGTe7BSMbzDcaPyT5kzu2uga6RED3i52uhYW4UeVCx4j4yGJlhda42QNJ/kMlF0QqKcrCFsecIK8bizSuGxkuNYgUJcMVctK4uAX5YThH3EVaQZE0XtaJge1gkUoaf3AJOos0vldU/SHBWeL+nQXvI6ISt4t5eFSerjcbwotVhimCg/XKg3mtYK4X4jBMk191p6X/LhTBXLzq9ooUP3lIV1DASBEDnTw8ZG0TztY4HQ8KZuA6cZfIslgZbXvSeZ1KztYS2snRC3C9KG5ZGt0p6MZKUak3isL3g/D3PvyaZMencT3CLacLFnyocLn9BdGUxr2Ee/FWu4uqhwmCJmQ7t03ExrlaJ5GtoAfnJd3bCvM90co8zU5kAt4WKfZPQfCWigsSscvzMUu4wwxx/+gW3GpYkiFOpg+/CTf6ChtSWyNeHrPTmyhq1mLsLhLDsYX+tvGQ2JV1mFn4fyael6fNMtqOpLN6nnWpf2kjQ5udyC/iyGeJXcmwHgeKGFkpONQX8l3+XdCSnSpjZLi4UY6Vn95M8V48N/WvV1lkZ2F1sqXuS2Qz7tOTfttJCl1Vv632NcPE5iL1kR17LddapnzXWlZjnnUFmbpotjPFwX+KV/cH5cE+TrjFbOEq07GvCPax4hGuGOy9wu2240uRrjcI11kh3JHY/StFsI9pw96GC8lSYMZKs/R7ntz1ykCt9NuX5i7tRLpE+rtRZUHsE3fqVfhIFMON+FF8++hVGewjREqfrLIgzhUFsaj3JfFAsaLKjo6QUZDuwn8zxDPPcuVTlOXiXaxIUcYU+uui2QpXiR07Ea/X6B8pUuVc8QQ0LbUp8nRbHSO/CQrzTWprRQpfJ56HqnESXk0yhzexty5uFbvxlpwHDSVG4r1kw80DUTQePydFzV7hy0aXuHT1ixMc21i8OY6Tfxp7Qe4qg4lxgq5ksTG/LMVnihzfL/L/Jep/qBkIRon6kb2RbVHyZwWCW30kzzKfi5fHMj4tHyGY9YaC/vdVVvmGaDcvD8cF4qVwv8L/X+ADsdDV4mPPFjl5JNxlnHDNrH7MEY8Wxc8Mn4gNWibqyaBihDjyR/GTgdeQHwVNP1GH2bGM58jhYndnpzZHcKXxcspOnMxWUU82iZPL2hpB+Xfhf4N/AWFZBn4jwQGrAAAAAElFTkSuQmCC", note: "Blush"},
        {id: 'c2', name: "eyeliner", icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAACwUlEQVRoge1ZTU8UQRB9EoQoohE5CIhiosQ9iEcTPZDwa/w9eNZfoTEa48WrCRIOxg8WPCAGIoIxQQiIh64KwyxVXdUzzixkXtKpyezrqnpd090zvUCDk40BAE8BrFN7QvdOHB4DOMi12VozSkQbIfkHAB7SdbvWjBLxByH5fmoHdK929Dj5G2SvABim6x/lpZOOXif/A4ARhEcre692eIU8AzAD4FHm3vPy0qkOgwBWcLhifQdwqdaMCmAah0Kma86lMFhI18C7anUtvJO9bFireiZGaCpSMqQRN8/DU1ORRkgBvELn8p3/NJB+fys5ja4GAjhISv+i+8+xMeuc7N5BUAegmSPdhlMjpOo50p+5LvWls+qK/K043n/FHkI1PKtWD/XZ0wgS3kDeqGJN3LgA7JI9a1FA4Cmwq7IEpIqIfXRtFvD5U3JqmeylblwAdpz+shArUsfy+4vsTYRBsrRbub4d0ITsk+1zJMnLqzgpER4tIBzyWTFEdksiaEL4KPSCI+Ag2W2FU0TIpkTQhHAyFx0BLUL4iNUj5DLZpIrwCpFSkQ2Fs0rWI4TPmb9JBE3IOtmUimgH2yxkWOHkwRVZlQiakDWyI46AzF1TODyqYw6/o7m+HdCEfCV7wxFwguyywuFkrjv8juf6dkATwv9EeYQwd0nh8OMxrnDyuEZ2RSJYhEw4ArIQ7e84HtUUIWJFNLQQXjcWHH0WqE8rwuP3raEIDwDOI7z+/0biYck5hN19B7bdvY+4+9RXwzsEIfcNfqeI+14jxTbENiV4xxCwRdxF6BsiAHwhe9vgd5LsR40Ue2mcI3vPEJA5cyorIEXIJ40UEzJP9q4hIHPmVVbAIlmLEOZ81kgxIfxcThkCMkd9lgmc1KTKOspRKxLDGPxfcaPHejqKqwl+LSuciuyhc6y9dPh97fD7oqiIBlXjH5yR4Rf0cUaDAAAAAElFTkSuQmCC", note: "The best category"},
        {id: 'c3', name: "mascara", icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAD60lEQVRoge3XW4iVVRTA8d/xUmiGNWZqJhYkpkRhiF00fSmSiCiKLg9RQVZUFFFBBIVJDxYFZUJFdBEhuhgURqRPSlKhBJWWkJakoSaRlHnJy5we1v74vrM9MzozzvTy/eHjsNfal7X3Xpd9qKmpqampqamp6S8GD/B6o3EyDgzwur3mtvRVGYyd+KmLMWf2q0W94BQcxJ5MPglN/NJmzAJ0YnZvFx3U24HdcDGGYmMmvzT9/tjGhrvQwL5MNw6v4IJjLTqkx2aWjBSnvz2Tz0i/6zL5Ten3s0w+F2djC77JdI/jQezGhj7Y2i1rhfuMyOTLhQvdUZFNxmER5GMq8gbWpP6PZvMMwx9JN+2EWZ0xRMTBEZGFCs7Av0k3uiJflgx6NZvn7iTfiVMz3dNJ9/UJs7oN56RFtmbyZ5L844rshiT7W7hQwUXiRpu4JZtnqoiXTszKdNPxA67tqdFjcH4muyoZsCrrtzvJZybZZPyZZA9U+k4Sh9DEkmzuDmxKurcyXUPcUBOP9HQj64Rvn1aRLUiTvViRvZdkn6b2BGxOsmXKDHk5diX5aq2uOQ7fJt06ESdVHkq6bRje043sSIPHVmTrk+zq1L43tfdgIqYoT3xtWvQkPItDSb5cZL2CWSJzNUWKPiuz4zqRMDqFu/aYwl1GpvbM1N4hgn6uCPCmqObzlL6/GqNEnfg5yQ5joTL1j8VikTia+DKNqfKw8gCe6s0mhqcFDijfZavShPNxDfZXDCh0RbZ5Ab9WZBuEaw3GHLye5m6KTDdf3FzBZKxM+s6kb1T0o7BIJIBumZYmWZ/a81J7lziZ4pTy70jW3ovP8Tw+UdaHou+HWqv3LLybNtdM/W/MbBsqbryJl461kSLPf5A29Y8y77fbQE++jXhOnOZ03I43RSAXfQ7hNUe72unKm9qqtci2ZUXqvLAL4zfhbdwj3lJTMR7niVi6FS+Lp0f1lvaLU97XxSa3icw4PrNnmEgsRQLaLupRt4xTuk4RB0Vhe0P5CDxeJohnyPdtDP9NpO/HcGHq30g2zMB9WIq/KmO+0Fpgu2RRtth+cTMjuxt0nMzBR1pvaY8onsXXlUt+JR6gjaNmbcMlWgP5fZx7AjaQMwXvKIM6/34XbrlUvAwm9WTy2eKqm+Jk8mzRH0wU/zv2KjexRcTJZSJD5YwQWfQ7cRgt3Km8iTVpgYGkA08oK3zVrdeLFL5CPF+qHrOiOsmToug0RVrsy5+uvtIQnrFYFNF2bndQ1JGbpWI9KA0ong/3D7TVx0GHqGPX40pRMI96NC5RXt9AxEO/sVkE9RX/tyF9pUP8Ra2pqampqampqalpy3/R7VAb/fZakwAAAABJRU5ErkJggg==", note: undefined},
        {id: 'c4', name: "lipstick", icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAADFklEQVRoge3XW4iVVRTA8d+MY2rOaJJNpRU1GV2UDIYGjCiCil4kgnox6DHoSklRD0U9VW9JEJRYERUERUUR9CCUD2YXutBFibIyS7BQcjIdlPH0sNbpXJxxPHPOnHrYf1h8t73XXnvvtddaH4VCoVAoFAqFQqHw39DTZt8RXIUrMIQz8tuXeAUvYX++68ctuBkrUcGv2I5NeB+f5fuucBEew8856LFkL+5N2Xsc7X/Aozhvpow/FWvxedPAv2C9WOULMYClYuW3TGDolvy2FAuwPJ9fwK6mth/iDixq1/heXIfXcahugD14RrhT7xQ6VuPblNVTtJ2Fa8Sk9tWNdxAvCxdu6SgM4RHsaFL2ahpzQivKpslc3Ii3NC7i93gQZ07W8QLhOptxpK7jR7hNB7a3DQZxD76os2scH+BunF9t2OzLv+EJ4fP/N1biSezWaPOOPvQ1NV4kwuoBMetPMNYtSyfhRKzClRjGwqbvf8Js3KfxgNXLIbGtG4SbjaTimWJ+Gn2nOPhf4fAktu1L22fXR4FleBMr8vk7EaGGMWeCAXfhx5Tt+Cnf7UnZL3x5NNsvEJGpHydjMZaI4DKEc/N62gRjHRahf36dfd/gBpF7jqIfr6kdqPtFlFqFu0TO+DiNnCq5TVcO4FM8JxLp5Zgndqi6M2+krf8yUVzuEdn14bzfgNtTSZVenCNW8CwRDs/O60KRGOfmdSD7/JULcDDvR7FTVAg7U6o7PF43Vh/WieRYweN4SAulzE34OztsxEnH27GDDOCdtGFMVAHTYkStdNgqSopusTzHrIhwe1m7CpcIn61m+AdMXZq0Qw9uVfOGr4XbdoR5eFot678nokynWZa6qwd/vYhUHedakfmr+eVZnN4BvYtFNTGWun/H9R3Qe0xOwfMislREJFqnFt9bYUX2rYbzI3hR/DZ0jWG8rbHI3JaGrcElYtJzUgbz3Zpss01j/ngXl3ZzAs1UV/UPrSW+SvZ5ShSDbdHOP3szs8SKXo2LRfU8qFbgjQrf3yoi0UZRkI4fpalQKBQKhUKhUJgJ/gGNMw8EOJ/Q4wAAAABJRU5ErkJggg==", note: undefined}
        ];
        this.storage.set("categories", this.categories);
    }
    return this.categories;
 }
 //update stroge with the new value passed into the function
 async setCategories(newCategories){
   this.storage.set("categories", newCategories);
 }
 //async getIcons(){
    //for(let i=0; i<this.categories.length;i++){
      //this.getIconText(this.categories[i].icon);
      //}
      //return this.iconData;
  //}

  //async getIconText(textFileName: string){
    //alert(textFileName);
      //await this.file.readAsText(this.file.applicationDirectory, 'www/assets/imageData/' + textFileName).then(val =>
      //{
        //alert(textFileName);
        //this.iconData.push(val);
      //});
  //}
}
